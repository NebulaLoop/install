## iFRA INSTALLER

### Prepare infrastructure
- Install Docker : https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-20-04


### Deploy iFRA via Docker swarm

1. Initial Swarm
```
docker swarm init --advertise-addr <IP>
```
2. Create .env
```
cp .env.example .env
```
3. Import .env to OS env
```
export $( grep -vE "^(#.*|\s*)$" .env )
```
4. creare docker-compose file from template
```
envsubst < docker-compose.template.yaml > docker-compose.yaml
```
5. run docker-compose with docker swarm
```shell
docker stack deploy -c docker-compose.yaml ifra-app
```
6. checking app's status
```
docker service ls
```
7. access ifra app
Go to https://127.0.0.1


## Uninstall app
```
docker stack rm ifra-app
```
