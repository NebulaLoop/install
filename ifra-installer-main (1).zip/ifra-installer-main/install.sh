#!/bin/bash

FILES=$(ls images/*.tar)

# Loop through files and load/import them into Docker
for FILE in ${FILES}; do
    # Extract vendor, image, and tag from file name
    FILENAME=$(basename "${FILE}")
    VENDOR=$(echo "${FILENAME}" | cut -d '@' -f 1)
    IMAGE=$(echo "${FILENAME}" | cut -d '@' -f 2 | cut -d ':' -f 1)
    TAG=$(echo "${FILENAME}" | cut -d ':' -f 2 | cut -d '.' -f 1)

    # Load file into Docker image
    docker load -i "${FILE}"

 
done



echo "Start Docker"
docker-compose -f docker-compose.yaml  --env-file .env.yaml up