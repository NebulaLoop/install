#!/bin/ash

envsubst '${MF_NGINX_MQTTS_PORT}' < /etc/nginx/nginx.conf.template > /etc/nginx/nginx.conf
echo "run entrypoint"
exec nginx -g "daemon off;"