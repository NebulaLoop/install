#!/bin/bash
# MODE="pm2"
# BACKEND_T
# echo "Clone repositoris"

# git clone git@gitlab.com:ifra.io/ifraiot.git
# git clone git@github.com:ifraiot/ifra-frontend.git

# echo "checkout version"

# echo $MODE

# export GOARCH=amd64
# export GOOS=linux

# echo "Build Backend"
# cd ifraiot && make all && cd ..

# echo "Build Frontned"

# cd ifra-frontend && npm i --force && npm run build && cd ..

# zip installer.zip ifraiot/build/* ifra-frontend/dist/* install.sh



echo "Save image to files."
# Define an array of Docker image names and tags to save
IMAGE_NAMES_AND_TAGS=(
  "mainflux/vernemq:1.12.3"
  "nats:2.7.2-alpine"
  "timescale/timescaledb:latest-pg10"
  "redis:5.0-alpine"
  "mariadb:10.5.8"
  "ifrasoft/cms:0.2"
  "ifrasoft/rule-engine-manager:0.2"
  "ifrasoft/rule-engine-worker:0.2"
  "ifrasoft/integrator:0.2"
  "ifrasoft/things:0.2"
  "ifrasoft/mqtt-adapter:0.2"
  "ifrasoft/timescale-writer:0.2"
  "hasura/graphql-engine:v2.24.0.cli-migrations-v2"
)

DEFAULT_VENDOR="my-default-vendor"

# Loop through the array and save each image to a separate file
for IMAGE_NAME_AND_TAG in "${IMAGE_NAMES_AND_TAGS[@]}"
do
    # Split the image name and tag using a colon as the delimiter
    IMAGE_NAME_WITH_VENDOR="${IMAGE_NAME_AND_TAG%:*}"
    TAG="${IMAGE_NAME_AND_TAG#*:}"

    # Split the image name and vendor using a slash as the delimiter
    IFS='/' read -ra IMAGE_NAME_PARTS <<< "$IMAGE_NAME_WITH_VENDOR"
    if [ ${#IMAGE_NAME_PARTS[@]} -eq 1 ]; then
        IMAGE_NAME="${IMAGE_NAME_PARTS[0]}"
        VENDOR="$IMAGE_NAME"
    else
        VENDOR="${IMAGE_NAME_PARTS[0]}"
        IMAGE_NAME="${IMAGE_NAME_PARTS[1]}"
    fi

    FILENAME="$VENDOR@$IMAGE_NAME:$TAG.tar"
    docker save  "$IMAGE_NAME_WITH_VENDOR" -o "images/$FILENAME"
done

echo "All Docker images have been saved to files."
